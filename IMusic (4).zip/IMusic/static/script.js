const mainView = document.getElementById('main-view');
const contentHeader = document.getElementById('content-header');
const audio = document.getElementById('audio-element');
const searchInput = document.getElementById('search-input');

const FAVORITES_KEY = 'imusic_favorites';
let currentView = 'all';

function getFavorites() {
    try {
        const raw = localStorage.getItem(FAVORITES_KEY);
        return raw ? JSON.parse(raw) : [];
    } catch { return []; }
}

function setFavorites(arr) {
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(arr));
}

/** Уникальный ключ песни: для локальной — id, для YouTube — строка id (video_id) */
function getFavoriteId(song) {
    if (song.is_external) return 'ext_' + (song.id || song.video_id || '');
    return 'loc_' + song.id;
}

function isFavorite(song) {
    const key = getFavoriteId(song);
    return getFavorites().some(f => getFavoriteId(f) === key);
}

function toggleFavorite(song, event) {
    if (event) event.stopPropagation();
    const fav = getFavorites();
    const key = getFavoriteId(song);
    const toSave = fav.filter(f => getFavoriteId(f) !== key);
    if (toSave.length === fav.length) {
        toSave.push(normalizeSongForFavorite(song));
    }
    setFavorites(toSave);
    refreshStarInCard(song);
    refreshFavoritesCount();
}

function normalizeSongForFavorite(song) {
    if (song.is_external) {
        return { id: song.id, title: song.title, artist: song.artist, cover: song.cover, is_external: true };
    }
    return {
        id: song.id, title: song.title, artist: song.artist,
        file_name: song.file_name, url: song.url || `/music/${encodeURIComponent(song.file_name)}`,
        cover: song.cover || `/api/cover/${encodeURIComponent(song.file_name)}`, is_external: false
    };
}

function refreshStarInCard(song) {
    document.querySelectorAll('.song-card').forEach(card => {
        const key = card.dataset.favId;
        if (key === getFavoriteId(song)) {
            const star = card.querySelector('.star-btn');
            if (star) star.classList.toggle('active', isFavorite(song));
        }
    });
}

function refreshFavoritesCount() {
    const btn = document.getElementById('btn-favorites');
    if (!btn) return;
    const n = getFavorites().length;
    const badge = btn.querySelector('.fav-count');
    if (n > 0) {
        if (!badge) {
            const span = document.createElement('span');
            span.className = 'fav-count';
            btn.appendChild(span);
        }
        btn.querySelector('.fav-count').textContent = n;
    } else {
        badge?.remove();
    }
}

/**
 * Отрисовка песен. Опции: append, showStar (звёздочка), showDownload (кнопка «Скачать» только для YouTube)
 */
function renderSongs(songs, append = false, options = {}) {
    const { showStar = true, showDownload = false } = options;
    if (!append) mainView.innerHTML = '';
    mainView.className = 'grid-view';

    songs.forEach(song => {
        const div = document.createElement('div');
        div.className = 'song-card';
        div.dataset.favId = getFavoriteId(song);
        if (song.is_external) div.classList.add('external-track');

        const coverUrl = song.is_external
            ? (song.cover || '')
            : (song.cover || `/api/cover/${encodeURIComponent(song.file_name)}`);
        const fav = showStar && isFavorite(song);

        let actions = '';
        if (showStar) actions += `<button class="star-btn ${fav ? 'active' : ''}" title="В избранное" aria-label="Избранное">★</button>`;
        if (showDownload && song.is_external) actions += `<button class="download-btn" title="Скачать в библиотеку">↓</button>`;

        div.innerHTML = `
            <div class="art" style="background-image: url('${coverUrl}'), url('default_art.png');">
                ${song.is_external ? '<div class="badge">YouTube</div>' : ''}
                ${actions ? `<div class="card-actions">${actions}</div>` : ''}
            </div>
            <div class="title">${escapeHtml(song.title)}</div>
            <div class="artist">${escapeHtml(song.artist)}</div>
        `;

        div.onclick = (e) => { if (!e.target.closest('.star-btn') && !e.target.closest('.download-btn')) playSong(song); };

        const starBtn = div.querySelector('.star-btn');
        if (starBtn) starBtn.onclick = (e) => toggleFavorite(song, e);

        const downloadBtn = div.querySelector('.download-btn');
        if (downloadBtn) downloadBtn.onclick = (e) => { e.stopPropagation(); downloadYouTube(song, downloadBtn); };

        mainView.appendChild(div);
    });
    refreshFavoritesCount();
}

/**
 * 2. ЗАГРУЗКА ДАННЫХ (Все песни, Артисты)
 */
async function loadSongs() {
    currentView = 'all';
    updateNavActive('btn-all');
    contentHeader.innerHTML = '<h1>Все песни</h1>';
    try {
        const res = await fetch('/api/songs');
        const songs = await res.json();
        renderSongs(songs, false, { showStar: true });
    } catch (err) {
        console.error("Ошибка загрузки песен:", err);
    }
}

async function loadSongsByArtist(artistName) {
    contentHeader.innerHTML = `<h1>${artistName}</h1>`;
    try {
        const res = await fetch(`/api/songs?artist=${encodeURIComponent(artistName)}`);
        const songs = await res.json();
        renderSongs(songs, false, { showStar: true });
    } catch (err) {
        console.error("Ошибка фильтрации:", err);
    }
}

/**
 * 3. ПОИСК
 */
let searchTimeout;
function handleSearch(query) {
    const clearBtn = document.getElementById('clear-search');
    if (clearBtn) clearBtn.style.display = query.length > 0 ? 'block' : 'none';
    clearTimeout(searchTimeout);
    
    if (!query.trim()) {
        if (currentView === 'artists') loadArtists();
        else if (currentView === 'favorites') loadFavorites();
        else loadSongs();
        return;
    }

    searchTimeout = setTimeout(async () => {
        contentHeader.innerHTML = `<h1>Результаты для "${query}"</h1>`;
        const res = await fetch(`/api/songs?search=${encodeURIComponent(query)}`);
        const localSongs = await res.json();
        renderSongs(localSongs, false, { showStar: true });

        const btn = document.createElement('button');
        btn.className = 'global-search-btn';
        btn.innerText = 'Искать в YouTube';
        btn.onclick = () => searchGlobally(query, btn);
        mainView.appendChild(btn);
    }, 300);
}

async function searchGlobally(query, btn) {
    btn.innerText = 'Ищем...';
    try {
        const res = await fetch(`/api/search_external?query=${encodeURIComponent(query)}`);
        const externalSongs = await res.json();
        btn.remove();
        const div = document.createElement('div');
        div.innerHTML = '<h2 style="grid-column: 1/-1; margin-top: 20px;">YouTube</h2>';
        mainView.appendChild(div);
        renderSongs(externalSongs, true, { showStar: true, showDownload: true }); 
    } catch (err) {
        btn.innerText = 'Ничего не найдено';
    }
}

function clearSearch() {
    searchInput.value = '';
    handleSearch('');
}

/**
 * 4. ПЛЕЕР И ТЕКСТ
 */
async function playSong(song) {
    let url;
    if (song.is_external) {
        // Поток через наш сервер — обход CORS, иначе браузер блокирует воспроизведение
        url = `/api/proxy_stream?video_id=${encodeURIComponent(song.id)}`;
    } else {
        url = song.url || `/music/${encodeURIComponent(song.file_name)}`;
    }
    if (!url) return;

    audio.src = url;
    audio.play().catch(err => {
        console.error("Ошибка воспроизведения:", err);
        alert("Не удалось воспроизвести: " + (song.title || 'трек'));
    });

    document.getElementById('cur-title').innerText = song.title;
    document.getElementById('cur-artist').innerText = song.artist || '';

    const playerArt = document.getElementById('player-art');
    const coverUrl = song.is_external ? (song.cover || '') : (song.cover || `/api/cover/${encodeURIComponent(song.file_name)}`);
    if (playerArt) playerArt.style.backgroundImage = coverUrl ? `url('${coverUrl}')` : 'none';

    const lyTitle = document.getElementById('lyrics-title');
    const lyArtist = document.getElementById('lyrics-artist');
    if (lyTitle) lyTitle.innerText = song.title;
    if (lyArtist) lyArtist.innerText = song.artist || '';

    loadLyrics(song);
}

async function loadLyrics(song) {
    const container = document.getElementById('lyrics-container');
    if (!container) return;

    container.innerText = "Загрузка текста...";

    if (song.is_external) {
        container.innerText = "Текст для YouTube треков пока не поддерживается.";
        return;
    }

    try {
        const res = await fetch(`/api/lyrics/${song.id}`);
        const data = await res.json();
        container.innerText = data.lyrics || "Текст не найден в базе.";
    } catch (err) {
        container.innerText = "Ошибка при получении текста.";
    }
}

/**
 * ЗАГРУЗКА АЛЬБОМОВ
 */
async function loadAlbums() {
    currentView = 'albums';
    updateNavActive('btn-albums');
    contentHeader.innerHTML = `
        <div class="header-row">
            <h1>Альбомы</h1>
            <div class="sort-controls">
                <span class="sort-label">Сортировка:</span>
                <button class="sort-btn ${sortAlbumsBy === 'name' ? 'active' : ''}" onclick="setAlbumSort('name')">По названию</button>
                <button class="sort-btn ${sortAlbumsBy === 'artist' ? 'active' : ''}" onclick="setAlbumSort('artist')">По артисту</button>
            </div>
        </div>
    `;
    try {
        const res = await fetch('/api/albums');
        let albums = await res.json();
        albums = sortAlbumsList(albums, sortAlbumsBy);
        mainView.innerHTML = '';
        mainView.className = 'grid-view';
        if (albums.length === 0) {
            mainView.innerHTML = '<p class="empty-msg">Альбомы не найдены.</p>';
            return;
        }
        albums.forEach(album => {
            const div = document.createElement('div');
            div.className = 'song-card album-card';
            const coverUrl = album.cover || '';
            div.innerHTML = `
                <div class="art" style="background-image: url('${coverUrl}'), url('default_art.png');"></div>
                <div class="title">${escapeHtml(album.title)}</div>
                <div class="artist">${escapeHtml(album.artist)}</div>
            `;
            div.onclick = () => loadAlbumTracks(album);
            mainView.appendChild(div);
        });
    } catch (err) {
        console.error("Ошибка загрузки альбомов:", err);
    }
}

/**
 * ЗАГРУЗКА АРТИСТОВ
 */
let sortArtistsBy = 'az';   // 'az' | 'za'
let sortAlbumsBy = 'name';  // 'name' | 'artist'

async function loadArtists() {
    currentView = 'artists';
    updateNavActive('btn-artists');
    contentHeader.innerHTML = `
        <div class="header-row">
            <h1>Артисты</h1>
            <div class="sort-controls">
                <span class="sort-label">Сортировка:</span>
                <button class="sort-btn ${sortArtistsBy === 'az' ? 'active' : ''}" onclick="setArtistSort('az')">А–Я</button>
                <button class="sort-btn ${sortArtistsBy === 'za' ? 'active' : ''}" onclick="setArtistSort('za')">Я–А</button>
            </div>
        </div>
    `;
    try {
        const res = await fetch('/api/artists');
        let artists = await res.json();
        artists = sortArtistsList(artists, sortArtistsBy);
        mainView.innerHTML = '';
        mainView.className = 'list-view';
        if (artists.length === 0) {
            mainView.innerHTML = '<p class="empty-msg">Артисты не найдены.</p>';
            return;
        }
        artists.forEach(artistName => {
            const item = document.createElement('div');
            item.className = 'artist-list-item';
            item.innerHTML = `<div class="artist-icon"></div><span>${escapeHtml(artistName)}</span>`;
            item.onclick = () => loadSongsByArtist(artistName);
            mainView.appendChild(item);
        });
    } catch (err) {
        console.error("Ошибка загрузки артистов:", err);
    }
}

function setArtistSort(mode) {
    sortArtistsBy = mode;
    loadArtists();
}

function setAlbumSort(mode) {
    sortAlbumsBy = mode;
    loadAlbums();
}

function sortArtistsList(arr, mode) {
    const a = [...arr];
    if (mode === 'za') a.sort((x, y) => (y || '').localeCompare(x || '', 'ru'));
    else a.sort((x, y) => (x || '').localeCompare(y || '', 'ru'));
    return a;
}

function sortAlbumsList(arr, mode) {
    const a = [...arr];
    if (mode === 'artist') a.sort((x, y) => (x.artist || '').localeCompare(y.artist || '', 'ru') || (x.title || '').localeCompare(y.title || '', 'ru'));
    else a.sort((x, y) => (x.title || '').localeCompare(y.title || '', 'ru'));
    return a;
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Загрузка треков альбома (по артисту и названию альбома)
async function loadAlbumTracks(album) {
    const title = typeof album === 'string' ? album : album.title;
    const artist = album.artist;
    contentHeader.innerHTML = `<h1>${title}</h1>${artist ? `<p class="subtitle">${artist}</p>` : ''}`;
    const params = new URLSearchParams();
    if (artist) params.set('artist', artist);
    params.set('album', title);
    const res = await fetch(`/api/songs?${params.toString()}`);
    const songs = await res.json();
    renderSongs(songs, false, { showStar: true });
}

/**
 * ЛЮБИМЫЕ
 */
function loadFavorites() {
    currentView = 'favorites';
    updateNavActive('btn-favorites');
    contentHeader.innerHTML = '<h1>Любимые</h1>';
    const fav = getFavorites();
    if (fav.length === 0) {
        mainView.innerHTML = '<p class="empty-msg">Добавьте песни в избранное, нажимая ★ на карточке.</p>';
        mainView.className = 'grid-view';
        return;
    }
    renderSongs(fav, false, { showStar: true, showDownload: true });
}

/**
 * Скачать трек с YouTube в библиотеку
 */
async function downloadYouTube(song, btnEl) {
    if (!song.id || !song.is_external) return;
    const prev = btnEl.textContent;
    btnEl.textContent = '…';
    btnEl.disabled = true;
    try {
        const res = await fetch('/api/download_youtube', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ video_id: song.id, title: song.title, artist: song.artist })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.detail || 'Ошибка скачивания');
        if (data.ok) {
            btnEl.textContent = '✓';
            btnEl.classList.add('downloaded');
            if (currentView === 'favorites') {
                setFavorites(getFavorites().filter(f => getFavoriteId(f) !== getFavoriteId(song)));
                loadFavorites();
            }
            if (data.id) loadSongs();
        }
    } catch (err) {
        alert(err.message || 'Не удалось скачать трек.');
        btnEl.textContent = prev;
        btnEl.disabled = false;
    }
}



function toggleLyrics() {
    const overlay = document.getElementById('lyrics-overlay');
    if (!overlay) return;
    overlay.style.display = (overlay.style.display === 'flex') ? 'none' : 'flex';
}

function updateNavActive(id) {
    document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
    document.getElementById(id)?.classList.add('active');
}

window.onload = () => { refreshFavoritesCount(); loadSongs(); };