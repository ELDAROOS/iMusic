import sqlite3
import os
import secrets
import hashlib
import hmac
import base64
from datetime import datetime, timedelta
import requests  # Нужно для поиска текста в сети
from fastapi import FastAPI, HTTPException, Response, Body, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, StreamingResponse, JSONResponse
from mutagen.mp3 import MP3
from mutagen.easyid3 import EasyID3
from mutagen.mp4 import MP4
from mutagen.id3 import ID3, USLT # Для чтения текста из MP3
from yt_dlp import YoutubeDL

app = FastAPI()

MUSIC_DIR = "music_storage"
STATIC_DIR = "static"

if not os.path.exists(MUSIC_DIR):
    os.makedirs(MUSIC_DIR)

YDL_OPTIONS = {
    'format': 'bestaudio/best',
    'default_search': 'ytsearch',
    'quiet': True,
    'no_warnings': True,
}

SESSION_COOKIE_NAME = "imusic_session"
SESSION_TTL_DAYS = 30

def init_db():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    # Добавляем колонку album_name
    cursor.execute('''CREATE TABLE IF NOT EXISTS songs 
        (id INTEGER PRIMARY KEY AUTOINCREMENT, 
         title TEXT, 
         artist TEXT, 
         album_name TEXT, 
         file_name TEXT, 
         lyrics TEXT)''')

    # --- USERS / AUTH ---
    cursor.execute('''CREATE TABLE IF NOT EXISTS users
        (id INTEGER PRIMARY KEY AUTOINCREMENT,
         username TEXT UNIQUE NOT NULL,
         password_hash TEXT NOT NULL,
         created_at TEXT NOT NULL)''')

    cursor.execute('''CREATE TABLE IF NOT EXISTS sessions
        (token TEXT PRIMARY KEY,
         user_id INTEGER NOT NULL,
         created_at TEXT NOT NULL,
         expires_at TEXT NOT NULL,
         FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)''')

    # --- FAVORITES (персональные) ---
    cursor.execute('''CREATE TABLE IF NOT EXISTS favorites
        (id INTEGER PRIMARY KEY AUTOINCREMENT,
         user_id INTEGER NOT NULL,
         is_external INTEGER NOT NULL,
         song_id INTEGER,
         video_id TEXT,
         title TEXT,
         artist TEXT,
         cover TEXT,
         created_at TEXT NOT NULL,
         UNIQUE(user_id, is_external, song_id, video_id),
         FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
         FOREIGN KEY(song_id) REFERENCES songs(id) ON DELETE CASCADE)''')

    # --- HISTORY ---
    cursor.execute('''CREATE TABLE IF NOT EXISTS listening_history
        (id INTEGER PRIMARY KEY AUTOINCREMENT,
         user_id INTEGER NOT NULL,
         is_external INTEGER NOT NULL,
         song_id INTEGER,
         video_id TEXT,
         title TEXT,
         artist TEXT,
         played_at TEXT NOT NULL,
         FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)''')

    # --- PLAYLISTS (скелет) ---
    cursor.execute('''CREATE TABLE IF NOT EXISTS playlists
        (id INTEGER PRIMARY KEY AUTOINCREMENT,
         user_id INTEGER NOT NULL,
         name TEXT NOT NULL,
         created_at TEXT NOT NULL,
         FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)''')

    cursor.execute('''CREATE TABLE IF NOT EXISTS playlist_tracks
        (id INTEGER PRIMARY KEY AUTOINCREMENT,
         playlist_id INTEGER NOT NULL,
         sort_index INTEGER NOT NULL,
         is_external INTEGER NOT NULL,
         song_id INTEGER,
         video_id TEXT,
         title TEXT,
         artist TEXT,
         cover TEXT,
         FOREIGN KEY(playlist_id) REFERENCES playlists(id) ON DELETE CASCADE)''')
    conn.commit()
    conn.close()


def _now_iso():
    return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def _hash_password(password: str) -> str:
    """PBKDF2-HMAC-SHA256 без внешних библиотек."""
    if not isinstance(password, str) or len(password) < 6:
        raise HTTPException(status_code=400, detail="Пароль должен быть минимум 6 символов")
    salt = secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 200_000)
    return "pbkdf2_sha256$200000$" + base64.b64encode(salt).decode() + "$" + base64.b64encode(dk).decode()


def _verify_password(password: str, stored: str) -> bool:
    try:
        algo, iters, salt_b64, dk_b64 = stored.split("$", 3)
        if algo != "pbkdf2_sha256":
            return False
        iters_i = int(iters)
        salt = base64.b64decode(salt_b64.encode())
        dk = base64.b64decode(dk_b64.encode())
        cand = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iters_i)
        return hmac.compare_digest(cand, dk)
    except Exception:
        return False


def _create_session(user_id: int) -> str:
    token = secrets.token_urlsafe(32)
    created = datetime.utcnow()
    expires = created + timedelta(days=SESSION_TTL_DAYS)
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO sessions (token, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)",
        (token, user_id, created.replace(microsecond=0).isoformat() + "Z", expires.replace(microsecond=0).isoformat() + "Z")
    )
    conn.commit()
    conn.close()
    return token


def _get_user_by_session_token(token: str):
    if not token:
        return None
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute(
        "SELECT u.id, u.username, s.expires_at FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token = ?",
        (token,)
    )
    row = cursor.fetchone()
    if not row:
        conn.close()
        return None
    uid, username, expires_at = row
    # простая проверка истечения (лексикографически iso Z работает)
    if expires_at and expires_at < _now_iso():
        cursor.execute("DELETE FROM sessions WHERE token = ?", (token,))
        conn.commit()
        conn.close()
        return None
    conn.close()
    return {"id": uid, "username": username}


def _require_user(request: Request):
    token = request.cookies.get(SESSION_COOKIE_NAME)
    user = _get_user_by_session_token(token)
    if not user:
        raise HTTPException(status_code=401, detail="Требуется вход")
    return user

def sync_music_to_db():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    
    # Рекурсивный поиск файлов во всех подпапках
    for root, dirs, files in os.walk(MUSIC_DIR):
        for file_name in files:
            if not (file_name.endswith('.mp3') or file_name.endswith('.m4a')):
                continue
            path = os.path.join(root, file_name)
            rel_path = os.path.relpath(path, MUSIC_DIR)
            try:
                if file_name.endswith('.mp3'):
                    audio = EasyID3(path)
                    title = audio.get('title', [file_name])[0]
                    artist = audio.get('artist', ['Неизвестный исполнитель'])[0]
                    album = audio.get('album', [os.path.basename(root)])[0]
                else:
                    # .m4a (MP4)
                    f = MP4(path)
                    title = (f.get('\xa9nam') or [file_name])[0]
                    artist = (f.get('\xa9ART') or ['Неизвестный исполнитель'])[0]
                    album = (f.get('\xa9alb') or [os.path.basename(root)])[0]
            except Exception:
                title = file_name
                artist = "Неизвестный исполнитель"
                album = os.path.basename(root)

            cursor.execute("SELECT id FROM songs WHERE file_name = ?", (rel_path,))
            if not cursor.fetchone():
                cursor.execute("INSERT INTO songs (title, artist, album_name, file_name) VALUES (?, ?, ?, ?)",
                               (title, artist, album, rel_path))
    conn.commit()
    conn.close()

init_db()
sync_music_to_db()


# --- AUTH API ---

@app.post("/api/auth/register")
def register(payload: dict = Body(...)):
    username = (payload.get("username") or "").strip()
    password = payload.get("password") or ""
    if len(username) < 3:
        raise HTTPException(status_code=400, detail="Логин должен быть минимум 3 символа")
    pw_hash = _hash_password(password)
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO users (username, password_hash, created_at) VALUES (?, ?, ?)",
            (username, pw_hash, _now_iso())
        )
        user_id = cursor.lastrowid
        conn.commit()
    except sqlite3.IntegrityError:
        conn.close()
        raise HTTPException(status_code=400, detail="Такой логин уже существует")
    conn.close()
    token = _create_session(user_id)
    resp = JSONResponse({"ok": True, "user": {"id": user_id, "username": username}})
    resp.set_cookie(SESSION_COOKIE_NAME, token, httponly=True, samesite="lax", max_age=SESSION_TTL_DAYS * 86400)
    return resp


@app.post("/api/auth/login")
def login(payload: dict = Body(...)):
    username = (payload.get("username") or "").strip()
    password = payload.get("password") or ""
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("SELECT id, password_hash FROM users WHERE username = ?", (username,))
    row = cursor.fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=400, detail="Неверный логин или пароль")
    user_id, pw_hash = row
    if not _verify_password(password, pw_hash):
        raise HTTPException(status_code=400, detail="Неверный логин или пароль")
    token = _create_session(user_id)
    resp = JSONResponse({"ok": True, "user": {"id": user_id, "username": username}})
    resp.set_cookie(SESSION_COOKIE_NAME, token, httponly=True, samesite="lax", max_age=SESSION_TTL_DAYS * 86400)
    return resp


@app.post("/api/auth/logout")
def logout(request: Request):
    token = request.cookies.get(SESSION_COOKIE_NAME)
    if token:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        cursor.execute("DELETE FROM sessions WHERE token = ?", (token,))
        conn.commit()
        conn.close()
    resp = JSONResponse({"ok": True})
    resp.delete_cookie(SESSION_COOKIE_NAME)
    return resp


@app.get("/api/auth/me")
def me(request: Request):
    token = request.cookies.get(SESSION_COOKIE_NAME)
    user = _get_user_by_session_token(token)
    return {"user": user}

# --- НОВЫЙ ЭНДПОИНТ ДЛЯ ТЕКСТА ---

@app.get("/api/lyrics/{song_id}")
def get_lyrics(song_id: int):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("SELECT title, artist, lyrics FROM songs WHERE id = ?", (song_id,))
    row = cursor.fetchone()
    
    if not row:
        conn.close()
        raise HTTPException(status_code=404, detail="Песня не найдена")
    
    title, artist, lyrics = row
    
    # Если текста нет в базе, пробуем найти его в интернете через Lyrics.ovh
    if not lyrics:
        try:
            # Бесплатное API для поиска текста
            url = f"https://api.lyrics.ovh/v1/{artist}/{title}"
            response = requests.get(url, timeout=5)
            if response.status_code == 200:
                lyrics = response.json().get("lyrics")
                # Сохраняем в базу, чтобы не искать снова
                cursor.execute("UPDATE songs SET lyrics = ? WHERE id = ?", (lyrics, song_id))
                conn.commit()
        except Exception as e:
            print(f"Ошибка поиска в сети: {e}")

    conn.close()
    return {"lyrics": lyrics if lyrics else "Текст пока не найден для этого трека."}

# --- ОСТАЛЬНЫЕ МАРШРУТЫ ---

@app.get("/api/artists")
def get_artists():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("SELECT DISTINCT artist FROM songs WHERE artist IS NOT NULL AND artist != '' ORDER BY LOWER(artist)")
    rows = cursor.fetchall()
    conn.close()
    return [r[0] for r in rows]


@app.get("/api/songs")
def get_songs(artist: str = None, album: str = None, search: str = None):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    if search:
        q = f"%{search}%"
        cursor.execute(
            "SELECT id, title, artist, album_name, file_name FROM songs WHERE title LIKE ? OR artist LIKE ? OR album_name LIKE ? ORDER BY artist, title",
            (q, q, q)
        )
    elif artist and album:
        cursor.execute(
            "SELECT id, title, artist, album_name, file_name FROM songs WHERE artist = ? AND album_name = ? ORDER BY title",
            (artist, album)
        )
    elif artist:
        cursor.execute(
            "SELECT id, title, artist, album_name, file_name FROM songs WHERE artist = ? ORDER BY album_name, title",
            (artist,)
        )
    elif album:
        cursor.execute(
            "SELECT id, title, artist, album_name, file_name FROM songs WHERE album_name = ? ORDER BY artist, title",
            (album,)
        )
    else:
        cursor.execute("SELECT id, title, artist, album_name, file_name FROM songs ORDER BY artist, album_name, title")
    rows = cursor.fetchall()
    conn.close()
    return [
        {"id": r[0], "title": r[1], "artist": r[2], "album_name": r[3] or "", "file_name": r[4], "url": f"/music/{r[4]}", "cover": f"/api/cover/{r[4]}", "is_external": False}
        for r in rows
    ]


# --- FAVORITES API (в базе, привязано к пользователю) ---

@app.get("/api/favorites")
def list_favorites(request: Request):
    user = _require_user(request)
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute(
        """SELECT is_external, song_id, video_id, title, artist, cover, created_at
           FROM favorites
           WHERE user_id = ?
           ORDER BY created_at DESC""",
        (user["id"],)
    )
    rows = cursor.fetchall()
    conn.close()
    out = []
    for is_ext, song_id, video_id, title, artist, cover, created_at in rows:
        if is_ext:
            out.append({"id": video_id, "title": title, "artist": artist, "cover": cover, "is_external": True})
        else:
            # подтягиваем локальные данные по song_id
            if not song_id:
                continue
            conn2 = sqlite3.connect('database.db')
            c2 = conn2.cursor()
            c2.execute("SELECT id, title, artist, album_name, file_name FROM songs WHERE id = ?", (song_id,))
            r = c2.fetchone()
            conn2.close()
            if r:
                out.append({"id": r[0], "title": r[1], "artist": r[2], "album_name": r[3] or "", "file_name": r[4], "url": f"/music/{r[4]}", "cover": f"/api/cover/{r[4]}", "is_external": False})
    return out


@app.post("/api/favorites")
def add_favorite(request: Request, payload: dict = Body(...)):
    user = _require_user(request)
    is_external = bool(payload.get("is_external"))
    song_id = payload.get("song_id")
    video_id = payload.get("video_id")
    title = payload.get("title")
    artist = payload.get("artist")
    cover = payload.get("cover")
    if is_external:
        if not video_id:
            raise HTTPException(status_code=400, detail="video_id обязателен")
    else:
        if not song_id:
            raise HTTPException(status_code=400, detail="song_id обязателен")
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    try:
        cursor.execute(
            """INSERT OR IGNORE INTO favorites
               (user_id, is_external, song_id, video_id, title, artist, cover, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (user["id"], 1 if is_external else 0, song_id, video_id, title, artist, cover, _now_iso())
        )
        conn.commit()
    finally:
        conn.close()
    return {"ok": True}


@app.delete("/api/favorites")
def remove_favorite(request: Request, is_external: int, song_id: int = None, video_id: str = None):
    user = _require_user(request)
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    if is_external:
        if not video_id:
            conn.close()
            raise HTTPException(status_code=400, detail="video_id обязателен")
        cursor.execute("DELETE FROM favorites WHERE user_id = ? AND is_external = 1 AND video_id = ?", (user["id"], video_id))
    else:
        if not song_id:
            conn.close()
            raise HTTPException(status_code=400, detail="song_id обязателен")
        cursor.execute("DELETE FROM favorites WHERE user_id = ? AND is_external = 0 AND song_id = ?", (user["id"], song_id))
    conn.commit()
    conn.close()
    return {"ok": True}

@app.get("/api/cover/{file_name:path}")
def get_cover(file_name: str):
    full_path = os.path.join(MUSIC_DIR, file_name)
    song_dir = os.path.dirname(full_path)

    # 1. Обложка внутри файла (MP3 или M4A)
    try:
        if full_path.lower().endswith('.m4a'):
            f = MP4(full_path)
            covr = f.get('covr')
            if covr:
                data = bytes(covr[0])
                return Response(content=data, media_type='image/jpeg')
        else:
            audio = MP3(full_path)
            if audio.tags:
                for tag in audio.tags.values():
                    if hasattr(tag, 'data') and hasattr(tag, 'mime') and 'image' in str(tag.mime):
                        return Response(content=tag.data, media_type=tag.mime)
    except Exception:
        pass

    # 2. Файл cover.jpg / folder.jpg в той же папке
    for img_name in ['cover.jpg', 'cover.png', 'folder.jpg', 'album.art']:
        img_path = os.path.join(song_dir, img_name)
        if os.path.exists(img_path):
            with open(img_path, "rb") as f:
                return Response(content=f.read(), media_type="image/jpeg")

    # 3. Если ничего не нашли - возвращаем 404 (JS подставит дефолтную картинку)
    return Response(status_code=404)

# :path позволяет принимать пути со слэшами (подпапки)
@app.get("/music/{file_name:path}")
def get_audio(file_name: str):
    full_path = os.path.join(MUSIC_DIR, file_name)
    if os.path.exists(full_path):
        return FileResponse(full_path)
    raise HTTPException(status_code=404, detail="Файл не найден")
@app.get("/api/search_external")
def search_external(query: str):
    try:
        with YoutubeDL(YDL_OPTIONS) as ydl:
            info = ydl.extract_info(f"ytsearch5:{query}", download=False)
            return [{"id": e.get('id'), "title": e.get('title'), "artist": e.get('uploader'), "url": e.get('url'), "cover": e.get('thumbnail'), "is_external": True} for e in info['entries']]
    except: raise HTTPException(status_code=500)


@app.get("/api/external_stream")
def get_external_stream(video_id: str):
    """Получить актуальный URL потока (для совместимости). Воспроизведение — через /api/proxy_stream."""
    if not video_id:
        raise HTTPException(status_code=400, detail="video_id обязателен")
    try:
        with YoutubeDL({**YDL_OPTIONS, 'format': 'bestaudio/best'}) as ydl:
            info = ydl.extract_info(f"https://www.youtube.com/watch?v={video_id}", download=False)
            if not info:
                raise HTTPException(status_code=404, detail="Видео не найдено")
            url = info.get('url')
            if not url and info.get('requested_formats'):
                url = info['requested_formats'][0].get('url')
            if not url:
                raise HTTPException(status_code=404, detail="Поток не найден")
            return {"url": url}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/proxy_stream")
def proxy_stream(video_id: str):
    """Проксирование потока YouTube через сервер — обход CORS, воспроизведение в браузере."""
    if not video_id:
        raise HTTPException(status_code=400, detail="video_id обязателен")
    try:
        with YoutubeDL({**YDL_OPTIONS, 'format': 'bestaudio/best'}) as ydl:
            info = ydl.extract_info(f"https://www.youtube.com/watch?v={video_id}", download=False)
            if not info:
                raise HTTPException(status_code=404, detail="Видео не найдено")
            url = info.get('url')
            if not url and info.get('requested_formats'):
                url = info['requested_formats'][0].get('url')
            if not url:
                raise HTTPException(status_code=404, detail="Поток не найден")
        stream_resp = requests.get(url, stream=True, timeout=30)
        stream_resp.raise_for_status()
        content_type = stream_resp.headers.get('Content-Type') or 'audio/webm'

        def iter_chunks():
            for chunk in stream_resp.iter_content(chunk_size=65536):
                if chunk:
                    yield chunk

        return StreamingResponse(iter_chunks(), media_type=content_type)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


def _find_downloaded_file(video_id: str, ext: str, within_sec: int = 120):
    """Найти только что скачанный файл по расширению в MUSIC_DIR."""
    import time
    cutoff = time.time() - within_sec
    for f in os.listdir(MUSIC_DIR):
        if f.endswith(ext):
            p = os.path.join(MUSIC_DIR, f)
            if os.path.isfile(p) and os.path.getmtime(p) >= cutoff:
                return f
    return None


@app.post("/api/download_youtube")
def download_youtube(payload: dict = Body(...)):
    """Скачать аудио с YouTube в music_storage. С FFmpeg — в MP3, без — в M4A."""
    video_id = payload.get("video_id")
    title = payload.get("title")
    artist = payload.get("artist")
    if not video_id:
        raise HTTPException(status_code=400, detail="video_id обязателен")
    out_tmpl = os.path.join(MUSIC_DIR, "%(title)s.%(ext)s")
    title_f = None
    artist_f = None
    info = None
    rel_path = None

    # 1) Пробуем скачать с конвертацией в MP3 (нужен FFmpeg)
    opts_mp3 = {
        **YDL_OPTIONS,
        'format': 'bestaudio/best',
        'outtmpl': out_tmpl,
        'postprocessors': [{'key': 'FFmpegExtractAudio', 'preferredcodec': 'mp3', 'preferredquality': '192'}],
    }
    try:
        with YoutubeDL(opts_mp3) as ydl:
            info = ydl.extract_info(f"https://www.youtube.com/watch?v={video_id}", download=True)
            if not info:
                raise HTTPException(status_code=404, detail="Видео не найдено")
            title_f = (title or info.get('title') or 'Unknown').strip()
            artist_f = (artist or info.get('uploader') or info.get('channel') or 'Неизвестный исполнитель').strip()
            rel_path = _find_downloaded_file(video_id, '.mp3')
    except Exception as e:
        err_msg = str(e).lower()
        if 'ffmpeg' in err_msg or 'ffprobe' in err_msg:
            # 2) Без FFmpeg — качаем лучший аудио в M4A
            opts_m4a = {
                **YDL_OPTIONS,
                'format': 'bestaudio[ext=m4a]/bestaudio/best',
                'outtmpl': out_tmpl,
            }
            try:
                with YoutubeDL(opts_m4a) as ydl:
                    info = ydl.extract_info(f"https://www.youtube.com/watch?v={video_id}", download=True)
                    if not info:
                        raise HTTPException(status_code=404, detail="Видео не найдено")
                    title_f = (title or info.get('title') or 'Unknown').strip()
                    artist_f = (artist or info.get('uploader') or info.get('channel') or 'Неизвестный исполнитель').strip()
                    rel_path = _find_downloaded_file(video_id, '.m4a')
                    if not rel_path:
                        rel_path = _find_downloaded_file(video_id, '.webm')
            except HTTPException:
                raise
            except Exception as e2:
                raise HTTPException(status_code=500, detail=str(e2))
        else:
            raise HTTPException(status_code=500, detail=str(e))

    if not info or not rel_path:
        raise HTTPException(status_code=500, detail="Файл после скачивания не найден")
    if not title_f:
        title_f = (title or info.get('title') or 'Unknown').strip()
    if not artist_f:
        artist_f = (artist or info.get('uploader') or info.get('channel') or 'Неизвестный исполнитель').strip()

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM songs WHERE file_name = ?", (rel_path,))
    if cursor.fetchone():
        conn.close()
        return {"ok": True, "message": "Уже в библиотеке", "file_name": rel_path}
    cursor.execute(
        "INSERT INTO songs (title, artist, album_name, file_name) VALUES (?, ?, ?, ?)",
        (title_f, artist_f, "", rel_path)
    )
    new_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return {
        "ok": True,
        "id": new_id,
        "title": title_f,
        "artist": artist_f,
        "file_name": rel_path,
        "url": f"/music/{rel_path}",
        "cover": f"/api/cover/{rel_path}",
        "is_external": False,
    }


@app.get("/api/albums")
def get_albums():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("""
        SELECT artist, album_name, MIN(file_name) as file_name
        FROM songs
        WHERE album_name IS NOT NULL AND album_name != ''
        GROUP BY artist, album_name
        ORDER BY LOWER(artist), LOWER(album_name)
    """)
    rows = cursor.fetchall()
    conn.close()
    return [{
        "artist": r[0],
        "title": r[1],
        "cover": f"/api/cover/{r[2]}"
    } for r in rows]


app.mount("/", StaticFiles(directory=STATIC_DIR, html=True), name="static")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)