import sqlite3
import os
from mutagen.easyid3 import EasyID3
from mutagen.mp3 import MP3

def scan():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    music_dir = "music_storage"
    
    files = [f for f in os.listdir(music_dir) if f.endswith('.mp3')]
    
    for file_name in files:
        path = os.path.join(music_dir, file_name)
        try:
            audio = EasyID3(path)
            title = audio.get('title', [file_name.replace('.mp3', '')])[0]
            artist = audio.get('artist', ['Неизвестный исполнитель'])[0]
        except:
            title = file_name.replace('.mp3', '')
            artist = "Неизвестный исполнитель"

        # Проверяем, есть ли уже в базе
        cursor.execute("SELECT id FROM songs WHERE file_name = ?", (file_name,))
        if not cursor.fetchone():
            cursor.execute("INSERT INTO songs (title, artist, file_name) VALUES (?, ?, ?)", 
                           (title, artist, file_name))
            print(f"Добавлено: {title} — {artist}")
    
    conn.commit()
    conn.close()

scan()